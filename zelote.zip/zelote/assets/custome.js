$('#form-member #muname').focus();
$('#form-member').attr('name', 'login');
$('#member').click(function(){
	$('#form-member').attr('name', 'login');
	$('#form-voucher').attr('name', '');
	$('#form-member #muname').focus();
});
$('#voucher').click(function(){
	$('#form-member').attr('name', '');
	$('#form-voucher').attr('name', 'login');
	$('#form-voucher #vuname').focus();
});
$( "#form-voucher #vuname" ).change(function() {
	setpass();
});
function setpass(){
  var pass = $('#form-voucher #vuname').val();
  $('#form-voucher #vpass').val(pass);
}